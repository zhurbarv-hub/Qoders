# -*- coding: utf-8 -*-
"""
Общие обработчики команд Telegram бота
Обрабатывают команды, доступные всем пользователям
"""

from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from bot.services.formatter import format_welcome_message, format_help_message
from bot.handlers.registration import start_registration, check_user_registered
from bot.handlers.client_buttons import get_client_keyboard
import logging

logger = logging.getLogger(__name__)

# Создаем роутер для общих команд
router = Router()


@router.message(Command("start"))
async def cmd_start(message: Message, user_role: str = 'unknown', state: FSMContext = None, **kwargs):
    """
    Обработчик команды /start
    Проверяет авторизацию клиента или отправляет приветственное сообщение
    
    Args:
        message (Message): Входящее сообщение
        user_role (str): Роль пользователя из middleware
        state (FSMContext): Контекст состояния FSM
    """
    try:
        telegram_id = message.from_user.id
        
        # Для неизвестных пользователей запускаем процесс регистрации
        if user_role == 'unknown':
            # Проверяем, может пользователь уже зарегистрирован но middleware не обновился
            is_registered, user = await check_user_registered(telegram_id)
            
            if is_registered:
                # Пользователь зарегистрирован, показываем приветствие
                welcome_text = f"""
👋 <b>С возвращением!</b>

Вы авторизованы как клиент: <b>{user.company_name}</b>

📋 <b>Доступные команды:</b>
• /list - Все ваши дедлайны (30 дней)
• /today - Дедлайны на сегодня
• /week - Дедлайны на неделю  
• /next <дни> - Дедлайны на N дней
• /help - Справка по командам

💡 <b>Используйте кнопки меню для быстрого доступа</b>
"""
                await message.answer(welcome_text, parse_mode='HTML', reply_markup=get_client_keyboard())
            else:
                # Пользователь не зарегистрирован, запускаем процесс регистрации
                await start_registration(message, state)
            
            logger.info(f"Пользователь {telegram_id} (роль: {user_role}) - регистрация: {is_registered}")
            return
        
        # Для зарегистрированных пользователей (admin, manager, client) показываем приветствие
        welcome_text = format_welcome_message(user_role)
        
        # Добавляем клавиатуру для клиентов
        if user_role == 'client':
            await message.answer(welcome_text, parse_mode="HTML", reply_markup=get_client_keyboard())
        else:
            await message.answer(welcome_text, parse_mode="HTML")
        
        logger.info(f"Пользователь {telegram_id} (роль: {user_role}) получил приветствие")
        
    except Exception as e:
        logger.error(f"Ошибка обработки команды /start: {e}")
        await message.answer("⚠️ Произошла ошибка при обработке команды")


@router.message(Command('help'))
async def cmd_help(message: Message, user_role: str = 'unknown', **kwargs):
    """
    Обработчик команды /help
    Показывает справку по доступным командам с учётом роли
    """
    user = message.from_user
    logger.info(f"📖 /help от пользователя {user.id} (роль: {user_role})")
    
    # Формируем справку с учётом роли
    help_text = "<b>📖 Справка по командам бота</b>\n\n"
    
    # Общие команды
    help_text += "<b>🔹 Общие команды:</b>\n"
    help_text += "/start - Начало работы\n"
    help_text += "/help - Эта справка\n"
    help_text += "/next - Ближайшие дедлайны\n\n"
    
    # Команды просмотра
    help_text += "<b>🔹 Просмотр дедлайнов:</b>\n"
    help_text += "/list - Все предстоящие дедлайны\n"
    help_text += "/today - Дедлайны на сегодня\n"
    help_text += "/week - Дедлайны на неделю\n\n"
    
    # Административные команды для админов и менеджеров
    if user_role in ['admin', 'manager']:
        help_text += "<b>🔹 Команды поиска и управления:</b>\n"
        help_text += "/search &lt;запрос&gt; - Поиск клиента по ИНН/названию\n"
        help_text += "/filter &lt;client_id&gt; - Фильтр дедлайнов по клиенту\n"
        help_text += "/client &lt;client_id&gt; - Карточка клиента\n"
        help_text += "/export - Экспорт данных (JSON/CSV)\n\n"
    
    # Команды управления - только для администратора
    if user_role == 'admin':
        help_text += "<b>🔹 Администрирование (только админ):</b>\n"
        help_text += "/notify &lt;client_id&gt; &lt;deadline_id&gt; - Отправить уведомление\n"
        help_text += "/stats - Статистика системы\n"
        help_text += "/status - Проверка здоровья системы\n"
        help_text += "/check - Ручной запуск проверки\n"
        help_text += "/health - Проверка Web API\n\n"
    
    # Дополнительная информация
    help_text += "<i>🔔 Бот автоматически отправляет уведомления о приближающихся дедлайнах</i>\n"
    
    if user_role == 'client':
        help_text += "<i>💡 Для управления дедлайнами используйте веб-консоль</i>\n"
        help_text += "<i>📋 Используйте кнопки меню ниже для быстрого доступа</i>"
    
    # Добавляем клавиатуру для клиентов
    if user_role == 'client':
        await message.answer(help_text, parse_mode='HTML', reply_markup=get_client_keyboard())
    else:
        await message.answer(help_text, parse_mode='HTML')


# Экспортируем роутер для использования в основном приложении
__all__ = ['router']