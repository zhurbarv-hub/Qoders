# Deployment Scripts for KKT System

Автоматизированные скрипты для развертывания проекта KKT на VDS сервере.

## 📋 Структура скриптов

| Скрипт | Фаза | Описание |
|--------|------|----------|
| `01_vds_setup.sh` | Phase 2 | Настройка VDS окружения (Python, PostgreSQL, Nginx, UFW) |
| `02_database_setup.sh` | Phase 3 | Настройка PostgreSQL и создание базы данных |
| `03_app_setup.sh` | Phase 4 | Клонирование репозитория и установка приложения |
| `04_services_setup.sh` | Phase 5 | Создание и запуск systemd сервисов |
| `05_nginx_setup.sh` | Phase 5 | Настройка Nginx и SSL сертификата |
| `06_backup_setup.sh` | Post | Настройка автоматических бэкапов |

## 🚀 Порядок выполнения

### Предварительные требования:

- VDS сервер с Ubuntu 22.04 LTS
- Доступ по SSH с правами root
- Зарегистрированный домен (для SSL)

### Шаг 1: Подготовка VDS

```bash
# Подключение к VDS
ssh root@YOUR_VDS_IP

# Скачать скрипты развертывания
git clone https://github.com/zhurbarv-hub/Qoders.git
cd Qoders/deployment

# Сделать скрипты исполняемыми
chmod +x *.sh
```

### Шаг 2: Установка окружения

```bash
# Запуск скрипта установки VDS
sudo ./01_vds_setup.sh
```

**Что делает:**
- Обновляет систему
- Устанавливает Python 3.11
- Устанавливает PostgreSQL
- Устанавливает Nginx
- Устанавливает Certbot
- Настраивает firewall (UFW)

**Время выполнения:** ~10-15 минут

### Шаг 3: Создание пользователя приложения

```bash
# Создать пользователя kktapp
adduser kktapp

# Добавить в группу sudo (опционально)
usermod -aG sudo kktapp
```

### Шаг 4: Настройка базы данных

```bash
# Установить пароль БД (опционально)
export DB_PASSWORD="YourStrongPassword123!"

# Запуск скрипта настройки БД
sudo ./02_database_setup.sh
```

**Что делает:**
- Создаёт базу данных `kkt_production`
- Создаёт пользователя БД `kkt_user`
- Настраивает оптимизации PostgreSQL
- Применяет схему базы данных

**Время выполнения:** ~5 минут

### Шаг 5: Развертывание приложения

```bash
# Запуск скрипта развертывания
sudo ./03_app_setup.sh
```

**Что делает:**
- Клонирует репозиторий в `/home/kktapp/kkt-system`
- Создаёт виртуальное окружение Python
- Устанавливает все зависимости
- Создаёт `.env` файл из шаблона

**Время выполнения:** ~10 минут

**⚠️ ВАЖНО:** После выполнения отредактируйте `.env` файл:

```bash
nano /home/kktapp/kkt-system/.env
```

Обязательные переменные:
- `DATABASE_URL` - Connection string PostgreSQL
- `JWT_SECRET_KEY` - Сгенерируйте сильный ключ
- `TELEGRAM_BOT_TOKEN` - Токен от @BotFather
- `TELEGRAM_ADMIN_IDS` - Ваш Telegram ID

### Шаг 6: Настройка systemd сервисов

```bash
# Запуск скрипта настройки сервисов
sudo ./04_services_setup.sh
```

**Что делает:**
- Создаёт `kkt-web.service` (веб-приложение)
- Создаёт `kkt-bot.service` (Telegram бот)
- Запускает оба сервиса
- Настраивает автозапуск при перезагрузке

**Время выполнения:** ~2 минуты

### Шаг 7: Настройка Nginx и SSL

```bash
# Установить домен
export DOMAIN="your-domain.com"

# Запуск скрипта настройки Nginx
sudo ./05_nginx_setup.sh
```

**Что делает:**
- Создаёт конфигурацию Nginx
- Настраивает reverse proxy
- Устанавливает SSL сертификат от Let's Encrypt
- Настраивает автоматическое обновление сертификата

**Время выполнения:** ~5 минут

### Шаг 8: Настройка автоматических бэкапов

```bash
# Запуск скрипта настройки бэкапов
sudo ./06_backup_setup.sh
```

**Что делает:**
- Создаёт скрипт автоматического бэкапа БД
- Настраивает cron задачу (ежедневно в 3:00)
- Выполняет тестовый бэкап

**Время выполнения:** ~1 минута

## ✅ Проверка развертывания

### 1. Проверка сервисов:

```bash
# Статус веб-приложения
sudo systemctl status kkt-web.service

# Статус бота
sudo systemctl status kkt-bot.service

# Логи
sudo journalctl -u kkt-web.service -f
sudo journalctl -u kkt-bot.service -f
```

### 2. Проверка веб-доступа:

```bash
# Health check
curl https://your-domain.com/health

# В браузере
https://your-domain.com
```

### 3. Проверка Telegram бота:

- Откройте бота в Telegram
- Отправьте команду `/start`
- Проверьте ответ

## 🔧 Управление сервисами

### Перезапуск приложения:

```bash
sudo systemctl restart kkt-web.service
sudo systemctl restart kkt-bot.service
```

### Просмотр логов:

```bash
# Веб-приложение
sudo journalctl -u kkt-web.service -n 100

# Бот
sudo journalctl -u kkt-bot.service -n 100

# Nginx
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### Обновление кода:

```bash
# Переключиться на пользователя kktapp
su - kktapp

# Перейти в директорию проекта
cd kkt-system

# Получить последние изменения
git pull origin main

# Перезапустить сервисы
sudo systemctl restart kkt-web.service
sudo systemctl restart kkt-bot.service
```

## 🔐 Безопасность

### Важные файлы и права доступа:

```bash
# .env файл (только владелец может читать/писать)
chmod 600 /home/kktapp/kkt-system/.env

# Проверка firewall
sudo ufw status verbose

# Проверка открытых портов
sudo netstat -tulpn | grep LISTEN
```

### Рекомендации:

1. **Пароли:**
   - Используйте сильные пароли (16+ символов)
   - Храните пароли в безопасном месте (password manager)

2. **SSH:**
   - Используйте SSH ключи вместо паролей
   - Отключите root login через SSH

3. **Обновления:**
   - Регулярно обновляйте систему: `sudo apt update && sudo apt upgrade`
   - Мониторьте логи на подозрительную активность

## 📊 Мониторинг

### Системные ресурсы:

```bash
# Использование CPU и памяти
htop

# Использование диска
df -h

# Статус служб
systemctl status kkt-*
```

### Бэкапы:

```bash
# Список бэкапов
ls -lh /home/kktapp/backups/

# Ручной бэкап
sudo -u kktapp /home/kktapp/backup-database.sh

# Логи бэкапов
tail -f /var/log/kkt-system/backup.log
```

## ❗ Решение проблем

### Сервис не запускается:

```bash
# Проверить логи
sudo journalctl -u kkt-web.service -xe

# Проверить конфигурацию
nano /home/kktapp/kkt-system/.env

# Проверить подключение к БД
psql -U kkt_user -d kkt_production
```

### Nginx ошибки:

```bash
# Проверить конфигурацию
sudo nginx -t

# Проверить логи
sudo tail -f /var/log/nginx/error.log
```

### SSL проблемы:

```bash
# Проверить сертификат
sudo certbot certificates

# Обновить сертификат вручную
sudo certbot renew
```

## 📞 Поддержка

Если возникли проблемы:
1. Проверьте логи соответствующего сервиса
2. Проверьте статус всех служб
3. Убедитесь, что .env файл заполнен корректно
4. Проверьте подключение к базе данных

---

**Версия:** 1.0  
**Дата:** 2025-12-13  
**Целевая платформа:** Ubuntu 22.04 LTS
