PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE _backup_clients(
  id INT,
  name TEXT,
  inn TEXT,
  contact_person TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  notes TEXT,
  is_active NUM,
  created_at NUM,
  updated_at NUM
);
INSERT INTO "_backup_clients" VALUES(1,'ООО Рога и Копыта','1234567890','Иванов Иван Иванович','+7 (999) 123-45-67','zhurbarv@gmail.com','г. Москва, ул. Примерная, д. 1','Тестовый клиент',1,'2025-12-10 19:42:49','2025-12-11 10:16:38');
INSERT INTO "_backup_clients" VALUES(2,'ООО Тестовая компания','1234567891',NULL,'+79879192484','info@info.ru',NULL,NULL,1,'2025-12-11 10:13:07','2025-12-12 09:51:42');
INSERT INTO "_backup_clients" VALUES(4,'ООО Тестовый','4457885844','Иванов Иван Иванович','+79879192488','test@test.su','г. Самара, Мичурина, 120 кв. 40','Тестовая организация',1,'2025-12-11 12:45:30','2025-12-11 12:45:30');
INSERT INTO "_backup_clients" VALUES(5,'ООО Вася и сыновья','1235854566','Треплов Василий Петрович','+79879122452','post@ruslan.ru','г. Самара, ул. Самарская, 145','Вася любит кофе',1,'2025-12-12 09:49:58','2025-12-12 09:50:56');
CREATE TABLE _backup_contacts(
  id INT,
  client_id INT,
  telegram_id TEXT,
  telegram_username TEXT,
  first_name TEXT,
  last_name TEXT,
  notifications_enabled NUM,
  registered_at NUM,
  last_interaction NUM,
  contact_name TEXT,
  phone TEXT,
  email TEXT,
  notification_days TEXT,
  code_expires_at NUM,
  notes TEXT,
  registration_code TEXT
);
CREATE TABLE _backup_users(
  id INT,
  email TEXT,
  password_hash TEXT,
  full_name TEXT,
  role TEXT,
  is_active NUM,
  created_at NUM,
  updated_at NUM
);
CREATE TABLE deadline_types (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_system BOOLEAN DEFAULT 0,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "deadline_types" VALUES(1,'ОФД (Оператор фискальных данных)','Срок действия договора с ОФД',0,1,'2025-12-11 07:28:49');
INSERT INTO "deadline_types" VALUES(2,'Фискальный накопитель (ФН)','Срок действия фискального накопителя',0,1,'2025-12-11 07:30:00');
INSERT INTO "deadline_types" VALUES(4,'Техническое обслуживание','Срок действия договора на ТО ККТ',0,1,'2025-12-11 07:30:28');
INSERT INTO "deadline_types" VALUES(5,'Тестовый','Просто тест',0,1,'2025-12-12 10:08:23');
CREATE TABLE deadlines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    deadline_type_id INTEGER NOT NULL,
    expiration_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (deadline_type_id) REFERENCES deadline_types(id)
);
INSERT INTO "deadlines" VALUES(1,1,1,'2025-12-31','active','Продление договора с ОФД до конца года','2025-12-11 07:30:51','2025-12-11 07:30:51',1);
CREATE TABLE notification_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    deadline_id INTEGER NOT NULL,
    recipient_telegram_id VARCHAR(50) NOT NULL,
    message_text TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'sent',
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    error_message TEXT,
    
    FOREIGN KEY (deadline_id) REFERENCES deadlines(id) ON DELETE CASCADE
);
CREATE TABLE users (
    -- Primary key
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    
    -- Authentication
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255),  -- NULL for clients not yet registered
    
    -- Common fields
    full_name VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'client' CHECK(role IN ('client', 'manager', 'admin')),
    
    -- Client-specific fields (NULL for managers/admins)
    inn VARCHAR(12) UNIQUE,  -- Only for clients (organizations)
    company_name VARCHAR(255),  -- Organization name for clients
    
    -- Contact information (for all users)
    phone VARCHAR(20),
    address TEXT,
    notes TEXT,
    
    -- Telegram integration (primarily for clients)
    telegram_id VARCHAR(50) UNIQUE,
    telegram_username VARCHAR(100),
    registration_code VARCHAR(20) UNIQUE,
    code_expires_at DATETIME,
    first_name VARCHAR(100),  -- From Telegram
    last_name VARCHAR(100),   -- From Telegram
    
    -- Notification settings (only for clients)
    notification_days TEXT DEFAULT '14,7,3',
    notifications_enabled BOOLEAN DEFAULT 1,
    
    -- Status and metadata
    is_active BOOLEAN NOT NULL DEFAULT 1,
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_interaction TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "users" VALUES(1,'zhurbarv@gmail.com',NULL,'Иванов Иван Иванович','client','1234567890','ООО Рога и Копыта','+7 (999) 123-45-67','г. Москва, ул. Примерная, д. 1','Тестовый клиент',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2025-12-10 19:42:49','2025-12-11 10:16:38');
INSERT INTO "users" VALUES(2,'info@info.ru',NULL,'ООО Тестовая компания','client','1234567891','ООО Тестовая компания','+79879192484',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2025-12-11 10:13:07','2025-12-12 09:51:42');
INSERT INTO "users" VALUES(3,'test@test.su',NULL,'Иванов Иван Иванович','client','4457885844','ООО Тестовый','+79879192488','г. Самара, Мичурина, 120 кв. 40','Тестовая организация',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2025-12-11 12:45:30','2025-12-11 12:45:30');
INSERT INTO "users" VALUES(4,'post@ruslan.ru',NULL,'Треплов Василий Петрович','client','1235854566','ООО Вася и сыновья','+79879122452','г. Самара, ул. Самарская, 145','Вася любит кофе',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2025-12-12 09:49:58','2025-12-12 09:50:56');
CREATE TABLE web_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    role VARCHAR(20) NOT NULL DEFAULT 'viewer',
    is_active BOOLEAN NOT NULL DEFAULT 1,
    telegram_id VARCHAR(50) UNIQUE,
    last_login DATETIME,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "web_users" VALUES(1,'admin','admin@kkt-system.local','$2b$12$A3ahw.Bglc/nsIJhCUSaSewmOhw/vACfPYu73UkEQDSzZ89Ayei4u','Администратор','admin',1,NULL,'2025-12-12 13:32:48.576277','2025-12-10 18:55:41','2025-12-12 13:32:48');
INSERT INTO "web_users" VALUES(2,'manager','info@info.ru','$2b$12$ORtRvXIjP5256znotBfT8.84ES71Y6CB8i5FDPuOMUZX4NRKncaVi','Ивано Иван Иванович','manager',1,NULL,NULL,'2025-12-12 10:52:26','2025-12-12 10:52:26');
CREATE INDEX idx_web_users_username ON web_users(username);
CREATE INDEX idx_web_users_email ON web_users(email);
CREATE INDEX idx_web_users_role ON web_users(role);
CREATE INDEX idx_web_users_is_active ON web_users(is_active);
CREATE INDEX idx_deadline_types_active ON deadline_types(is_active);
CREATE INDEX idx_deadlines_client ON deadlines(client_id);
CREATE INDEX idx_deadlines_expiration ON deadlines(expiration_date);
CREATE INDEX idx_deadlines_status ON deadlines(status);
CREATE INDEX idx_deadlines_type ON deadlines(deadline_type_id);
CREATE INDEX idx_notification_logs_deadline ON notification_logs(deadline_id);
CREATE INDEX idx_notification_logs_sent ON notification_logs(sent_at);
CREATE INDEX idx_notification_logs_status ON notification_logs(status);
CREATE VIEW v_active_deadlines_with_details AS
SELECT 
    d.id AS deadline_id,
    d.client_id,
    c.name AS client_name,
    c.inn AS client_inn,
    dt.type_name AS deadline_type_name,
    d.expiration_date,
    CAST((julianday(d.expiration_date) - julianday('now')) AS INTEGER) AS days_until_expiration,
    CASE 
        WHEN julianday(d.expiration_date) - julianday('now') < 0 THEN 'expired'
        WHEN julianday(d.expiration_date) - julianday('now') < 7 THEN 'red'
        WHEN julianday(d.expiration_date) - julianday('now') < 14 THEN 'yellow'
        ELSE 'green'
    END AS status_color,
    d.status,
    d.notes,
    ct.telegram_id AS contact_telegram_id,
    ct.telegram_username AS contact_telegram_username,
    ct.notifications_enabled
FROM deadlines d
INNER JOIN clients c ON d.client_id = c.id
INNER JOIN deadline_types dt ON d.deadline_type_id = dt.id
LEFT JOIN contacts ct ON c.id = ct.client_id
WHERE d.status = 'active' AND c.is_active = 1;
CREATE VIEW v_expiring_soon AS
SELECT *
FROM v_active_deadlines_with_details
WHERE days_until_expiration <= 14 AND days_until_expiration >= 0
ORDER BY days_until_expiration ASC;
CREATE VIEW v_dashboard_stats AS
SELECT 
    COUNT(DISTINCT c.id) AS total_clients,
    COUNT(DISTINCT CASE WHEN c.is_active = 1 THEN c.id END) AS active_clients,
    COUNT(d.id) AS total_deadlines,
    COUNT(CASE WHEN d.status = 'active' THEN 1 END) AS active_deadlines,
    COUNT(CASE WHEN julianday(d.expiration_date) - julianday('now') > 14 THEN 1 END) AS status_green,
    COUNT(CASE WHEN julianday(d.expiration_date) - julianday('now') BETWEEN 7 AND 14 THEN 1 END) AS status_yellow,
    COUNT(CASE WHEN julianday(d.expiration_date) - julianday('now') BETWEEN 0 AND 7 THEN 1 END) AS status_red,
    COUNT(CASE WHEN julianday(d.expiration_date) - julianday('now') < 0 THEN 1 END) AS status_expired
FROM clients c
LEFT JOIN deadlines d ON c.id = d.client_id;
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_inn ON users(inn) WHERE inn IS NOT NULL;
CREATE INDEX idx_users_telegram_id ON users(telegram_id) WHERE telegram_id IS NOT NULL;
CREATE UNIQUE INDEX idx_users_registration_code ON users(registration_code) WHERE registration_code IS NOT NULL;
CREATE INDEX idx_users_is_active ON users(is_active);
CREATE INDEX idx_deadlines_user_id ON deadlines(user_id);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('web_users',2);
INSERT INTO "sqlite_sequence" VALUES('deadline_types',5);
INSERT INTO "sqlite_sequence" VALUES('deadlines',2);
INSERT INTO "sqlite_sequence" VALUES('users',4);
COMMIT;
