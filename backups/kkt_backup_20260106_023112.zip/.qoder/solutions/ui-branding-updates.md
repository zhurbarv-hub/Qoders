# Обновление брендинга и UI элементов

**Дата:** 13 декабря 2025  
**Статус:** ✅ Выполнено

## Задачи

### 1. ✅ Ограничение на 16 цифр в номере ФН
**Местоположение:** `web/app/static/client-details.html`

**Изменения:**
- Добавлен атрибут `maxlength="16"` для поля "Номер ФН"
- Добавлен атрибут `pattern="[0-9]{1,16}"` для валидации только цифр
- Обновлена подсказка в label: "Номер ФН * (макс. 16 цифр)"

**Код:**
```html
<input class="mdl-textfield__input" type="text" id="fiscalDriveNumber" 
       maxlength="16" pattern="[0-9]{1,16}" required>
<label class="mdl-textfield__label" for="fiscalDriveNumber">Номер ФН * (макс. 16 цифр)</label>
```

### 2. ✅ Приближение надписи "Наименование ОФД" к выпадающему списку
**Местоположение:** `web/app/static/client-details.html`

**Изменения:**
- Удалена обертка MDL textfield с floating label
- Заменена на стандартный `<label>` с фиксированным позиционированием
- Label размещен непосредственно над select элементом с отступом 4px

**Было:**
```html
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
    <select class="mdl-textfield__input" id="ofdProvider">...</select>
    <label class="mdl-textfield__label" style="top: -20px;">Наименование ОФД</label>
</div>
```

**Стало:**
```html
<div style="width: 100%; margin-top: 12px;">
    <label style="display: block; margin-bottom: 4px; font-size: 12px; color: rgba(0,0,0,.54);">
        Наименование ОФД
    </label>
    <select class="mdl-textfield__input" id="ofdProvider">...</select>
</div>
```

### 3. ✅ Замена "KKT System" на "Релабс Центр"
**Местоположения:**
- `web/app/static/dashboard.html`
- `web/app/static/client-details.html`
- `web/app/static/login.html`
- `web/app/static/activate.html`
- `backend/static/dashboard.html`
- `backend/static/login.html`

**Изменения:**
- Обновлены все заголовки `<title>` в HTML
- Обновлены все заголовки `<h2>` в боковом меню
- Обновлен footer в activate.html: "© 2024 Релабс Центр"
- Обновлен title в JavaScript: `dashboard.js` (строка 460)

**Примеры:**
```html
<!-- До -->
<title>Панель управления - KKT System</title>
<h2>📈 KKT System</h2>

<!-- После -->
<title>Управление Дедлайнами - Релабс Центр</title>
<h2>📈 Релабс Центр</h2>
```

### 4. ✅ Замена "Панель управления" на "Управление Дедлайнами"
**Местоположения:**
- `web/app/static/dashboard.html` (4 вхождения)
- `web/app/static/js/dashboard.js` (2 вхождения)
- `backend/static/dashboard.html` (2 вхождения)

**Изменения:**
- Обновлены все заголовки страниц
- Обновлены заголовки в верхней панели
- Обновлены заголовки секции статистики
- Обновлен JavaScript для корректного отображения в `document.title`

**Примеры:**
```html
<!-- До -->
<h1 id="pageTitle">📊 Панель управления</h1>
<h3>📊 Панель управления</h3>

<!-- После -->
<h1 id="pageTitle">📊 Управление Дедлайнами</h1>
<h3>📊 Управление Дедлайнами</h3>
```

```javascript
// До
'statistics': 'Статистика',
document.title = `${sectionTitles[sectionId] || 'Dashboard'} - KKT Management`;

// После
'statistics': 'Управление Дедлайнами',
document.title = `${sectionTitles[sectionId] || 'Управление Дедлайнами'} - Релабс Центр`;
```

## Затронутые файлы

### Web приложение
1. `web/app/static/dashboard.html` - title, sidebar, header (4 изменения)
2. `web/app/static/client-details.html` - title, sidebar, ФН validation, OФД label (6 изменений)
3. `web/app/static/login.html` - title, header (2 изменения)
4. `web/app/static/activate.html` - title, footer (2 изменения)
5. `web/app/static/js/dashboard.js` - document.title (2 изменения)

### Backend приложение
6. `backend/static/dashboard.html` - title, header (2 изменения)
7. `backend/static/login.html` - title, header (2 изменения)

**Всего изменений:** 20 строк в 7 файлах

## Проверка

Все изменения применены успешно, синтаксических ошибок не обнаружено:
- ✅ HTML валидность сохранена
- ✅ JavaScript синтаксис корректен
- ✅ UTF-8 кодировка соблюдена (русский текст)
- ✅ Атрибуты валидации для номера ФН добавлены
- ✅ Брендинг обновлен во всех файлах

## Результаты

После применения изменений:
1. **Номер ФН** теперь принимает только цифры, максимум 16 символов
2. **Надпись "Наименование ОФД"** расположена ближе к выпадающему списку (4px отступ)
3. **"KKT System"** заменена на **"Релабс Центр"** во всех интерфейсах
4. **"Панель управления"** заменена на **"Управление Дедлайнами"** во всех местах

Все изменения согласуются с требованиями локализации интерфейса на русский язык.
