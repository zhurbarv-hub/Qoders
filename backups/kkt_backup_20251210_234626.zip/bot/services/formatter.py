# -*- coding: utf-8 -*-
"""
Сервис форматирования сообщений для Telegram бота
Преобразует данные из базы в красиво оформленные сообщения
"""

from typing import Dict, List
from datetime import datetime

import logging
logger = logging.getLogger(__name__)


def format_deadline_notification(deadline: Dict, days: int) -> str:
    """
    Форматирование уведомления о дедлайне
    
    Args:
        deadline (Dict): Информация о дедлайне
        days (int): Количество дней до истечения
        
    Returns:
        str: Отформатированное сообщение
    """
    try:
        # Определяем эмодзи по статусу
        status_emoji = {
            'green': '🟢',
            'yellow': '🟡',
            'red': '🔴',
            'expired': '❌'
        }.get(deadline.get('status', 'green'), '⚪')
        
        # Форматируем дату
        if deadline.get('expiration_date'):
            exp_date = deadline['expiration_date'].strftime('%d.%m.%Y') if hasattr(deadline['expiration_date'], 'strftime') else str(deadline['expiration_date'])
        else:
            exp_date = 'Не указана'
            
        message = (
            f"{status_emoji} <b>Уведомление о дедлайне</b>\n\n"
            f"<b>Клиент:</b> {deadline.get('client_name', 'Неизвестно')} (ИНН: {deadline.get('client_inn', 'Неизвестно')})\n"
            f"<b>Сервис:</b> {deadline.get('deadline_type_name', 'Неизвестно')}\n"
            f"<b>Дата окончания:</b> {exp_date}\n"
            f"<b>Осталось дней:</b> {deadline.get('days_remaining', days)}\n\n"
            f"⚠️ Пожалуйста, примите меры!"
        )
        
        return message
        
    except Exception as e:
        logger.error(f"Ошибка форматирования уведомления: {e}")
        return "⚠️ Уведомление о дедлайне\n\nПроизошла ошибка при формировании сообщения"


def format_deadline_list(deadlines: List[Dict]) -> str:
    """
    Форматирование списка дедлайнов
    
    Args:
        deadlines (List[Dict]): Список дедлайнов
        
    Returns:
        str: Отформатированный список
    """
    try:
        if not deadlines:
            return "📭 Нет предстоящих дедлайнов"
            
        # Определяем эмодзи по статусу
        status_emoji = {
            'green': '🟢',
            'yellow': '🟡',
            'red': '🔴',
            'expired': '❌'
        }
        
        # Формируем заголовок
        message = "<b>📋 Список предстоящих дедлайнов:</b>\n\n"
        
        # Добавляем каждый дедлайн
        for i, deadline in enumerate(deadlines, 1):
            emoji = status_emoji.get(deadline.get('status', 'green'), '⚪')
            
            # Форматируем дату
            if deadline.get('expiration_date'):
                exp_date = deadline['expiration_date'].strftime('%d.%m.%Y') if hasattr(deadline['expiration_date'], 'strftime') else str(deadline['expiration_date'])
            else:
                exp_date = 'Не указана'
                
            message += (
                f"{i}. {emoji} <b>{deadline.get('client_name', 'Неизвестно')}</b> "
                f"({deadline.get('client_inn', 'Неизвестно')})\n"
                f"   {deadline.get('deadline_type_name', 'Неизвестно')} - "
                f"{exp_date} ({deadline.get('days_remaining', 'N/A')} дней)\n\n"
            )
            
        return message.strip()
        
    except Exception as e:
        logger.error(f"Ошибка форматирования списка дедлайнов: {e}")
        return "⚠️ Произошла ошибка при формировании списка дедлайнов"


def format_statistics(stats: Dict) -> str:
    """
    Форматирование статистики системы
    
    Args:
        stats (Dict): Словарь со статистикой
        
    Returns:
        str: Отформатированная статистика
    """
    try:
        message = "<b>📊 Статистика системы:</b>\n\n"
        
        # Основные показатели
        message += f"👥 <b>Клиенты:</b>\n"
        message += f"   Всего: {stats.get('total_clients', 0)}\n"
        message += f"   Активные: {stats.get('active_clients', 0)}\n\n"
        
        message += f"📅 <b>Дедлайны:</b>\n"
        message += f"   Всего: {stats.get('total_deadlines', 0)}\n"
        message += f"   Активные: {stats.get('active_deadlines', 0)}\n\n"
        
        # Статусы дедлайнов
        message += f"🚦 <b>Статусы дедлайнов:</b>\n"
        message += f"   🟢 Хорошо (больше 14 дней): {stats.get('status_green', 0)}\n"
        message += f"   🟡 Внимание (7-14 дней): {stats.get('status_yellow', 0)}\n"
        message += f"   🔴 Срочно (меньше 7 дней): {stats.get('status_red', 0)}\n"
        message += f"   ❌ Просроченные: {stats.get('status_expired', 0)}\n"
        
        # Добавляем временную метку
        timestamp = datetime.now().strftime('%d.%m.%Y %H:%M')
        message += f"\n🕒 Последнее обновление: {timestamp}"
        
        return message
        
    except Exception as e:
        logger.error(f"Ошибка форматирования статистики: {e}")
        return "⚠️ Произошла ошибка при формировании статистики"


def format_welcome_message(user_role: str) -> str:
    """
    Форматирование приветственного сообщения
    
    Args:
        user_role (str): Роль пользователя ('admin' или 'client')
        
    Returns:
        str: Приветственное сообщение
    """
    if user_role == 'admin':
        message = (
            "👋 <b>Добро пожаловать в систему управления дедлайнами ККТ!</b>\n\n"
            "Вы вошли как <b>администратор</b>.\n\n"
            "<b>Доступные команды:</b>\n"
            "/start - Приветствие\n"
            "/help - Справка по командам\n"
            "/status - Статистика системы\n"
            "/list - Список всех дедлайнов\n"
            "/today - Дедлайны сегодня\n"
            "/week - Дедлайны на этой неделе\n"
            "/check - Принудительная проверка дедлайнов\n"
            "/search - Поиск клиента по ИНН/названию\n"
            "/settings - Настройки системы\n"
            "/export - Экспорт всех данных в JSON\n\n"
            "⚠️ Вы получаете уведомления обо всех дедлайнах."
        )
    else:
        message = (
            "👋 <b>Добро пожаловать в систему управления дедлайнами ККТ!</b>\n\n"
            "Вы вошли как <b>клиент</b>.\n\n"
            "<b>Доступные команды:</b>\n"
            "/start - Приветствие\n"
            "/help - Справка по командам\n"
            "/list - Список ваших дедлайнов\n"
            "/today - Ваши дедлайны сегодня\n"
            "/week - Ваши дедлайны на этой неделе\n"
            "/settings - Ваши настройки\n"
            "/mute - Отключить уведомления\n"
            "/unmute - Включить уведомления\n"
            "/export - Экспорт ваших данных в JSON\n\n"
            "ℹ️ Вы получаете уведомления только о дедлайнах вашего клиента."
        )
        
    return message


def format_help_message(user_role: str) -> str:
    """
    Форматирование справки по командам
    
    Args:
        user_role (str): Роль пользователя ('admin' или 'client')
        
    Returns:
        str: Сообщение со справкой
    """
    if user_role == 'admin':
        message = (
            "<b>❓ Справка по командам (администратор)</b>\n\n"
            "<b>Основные:</b>\n"
            "/start - Приветственное сообщение\n"
            "/help - Эта справка\n"
            "/settings - Настройки системы\n\n"
            "<b>Просмотр дедлайнов:</b>\n"
            "/list - Список всех активных дедлайнов\n"
            "/today - Дедлайны, истекающие сегодня\n"
            "/week - Дедлайны на ближайшие 7 дней\n\n"
            "<b>Административные:</b>\n"
            "/status - Статистика системы\n"
            "/check - Принудительная проверка и отправка уведомлений\n"
            "/search - Поиск клиента (ИНН/название)\n"
            "/export - Экспорт всех данных в JSON\n\n"
            "ℹ️ Администратор получает уведомления обо всех дедлайнах."
        )
    else:
        message = (
            "<b>❓ Справка по командам (клиент)</b>\n\n"
            "<b>Основные:</b>\n"
            "/start - Приветственное сообщение\n"
            "/help - Эта справка\n"
            "/settings - Ваши настройки\n\n"
            "<b>Просмотр дедлайнов:</b>\n"
            "/list - Список ваших активных дедлайнов\n"
            "/today - Ваши дедлайны, истекающие сегодня\n"
            "/week - Ваши дедлайны на ближайшие 7 дней\n\n"
            "<b>Управление уведомлениями:</b>\n"
            "/mute [дни] - Отключить уведомления (по умолчанию 7 дней)\n"
            "/unmute - Включить уведомления обратно\n"
            "/export - Экспорт ваших данных в JSON\n\n"
            "ℹ️ Клиент получает уведомления только о дедлайнах своего клиента."
        )
        
    return message


if __name__ == "__main__":
    # Тестирование форматтера
    print("=" * 50)
    print("ТЕСТ СЕРВИСА ФОРМАТИРОВАНИЯ")
    print("=" * 50)
    
    # Тест уведомления о дедлайне
    test_deadline = {
        'deadline_id': 1,
        'client_name': 'ООО "Ромашка"',
        'client_inn': '1234567890',
        'deadline_type_name': 'Регистрация ККТ',
        'expiration_date': datetime(2024, 12, 31),
        'days_remaining': 14,
        'status': 'yellow'
    }
    
    notification = format_deadline_notification(test_deadline, 14)
    print("Уведомление о дедлайне:")
    print(notification)
    print()
    
    # Тест списка дедлайнов
    test_deadlines = [test_deadline]
    deadline_list = format_deadline_list(test_deadlines)
    print("Список дедлайнов:")
    print(deadline_list)
    print()
    
    # Тест статистики
    test_stats = {
        'total_clients': 15,
        'active_clients': 12,
        'total_deadlines': 45,
        'active_deadlines': 38,
        'status_green': 20,
        'status_yellow': 12,
        'status_red': 6,
        'status_expired': 0
    }
    
    stats_message = format_statistics(test_stats)
    print("Статистика:")
    print(stats_message)
    print()
    
    # Тест приветственных сообщений
    admin_welcome = format_welcome_message('admin')
    client_welcome = format_welcome_message('client')
    print("Приветствие администратора:")
    print(admin_welcome)
    print()
    print("Приветствие клиента:")
    print(client_welcome)
    
    print("=" * 50)
    print("✅ Тесты пройдены успешно")
    print("=" * 50)