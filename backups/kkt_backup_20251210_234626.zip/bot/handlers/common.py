# -*- coding: utf-8 -*-
"""
Общие обработчики команд Telegram бота
Обрабатывают команды, доступные всем пользователям
"""

from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command
from bot.services.formatter import format_welcome_message, format_help_message
import logging

logger = logging.getLogger(__name__)

# Создаем роутер для общих команд
router = Router()


@router.message(Command("start"))
async def cmd_start(message: Message, user_role: str = 'unknown', **kwargs):
    """
    Обработчик команды /start
    Отправляет приветственное сообщение с информацией о боте
    
    Args:
        message (Message): Входящее сообщение
        user_role (str): Роль пользователя из middleware
    """
    try:
        # Форматируем приветственное сообщение
        welcome_text = format_welcome_message(user_role)
        
        # Отправляем сообщение
        await message.answer(welcome_text, parse_mode="HTML")
        
        logger.info(f"Пользователь {message.from_user.id} (роль: {user_role}) получил приветствие")
        
    except Exception as e:
        logger.error(f"Ошибка обработки команды /start: {e}")
        await message.answer("⚠️ Произошла ошибка при обработке команды")


@router.message(Command('help'))
async def cmd_help(message: Message, is_admin: bool = False, **kwargs):
    """
    Обработчик команды /help
    Показывает справку по доступным командам
    """
    user = message.from_user
    logger.info(f"📖 /help от пользователя {user.id}")
    
    # Формируем справку с учётом роли
    help_text = "<b>📖 Справка по командам бота</b>\n\n"
    
    # Общие команды
    help_text += "<b>🔹 Общие команды:</b>\n"
    help_text += "/start - Начало работы\n"
    help_text += "/help - Эта справка\n"
    help_text += "/settings - Ваши настройки\n\n"
    
    # Команды просмотра
    help_text += "<b>🔹 Просмотр дедлайнов:</b>\n"
    help_text += "/list - Все предстоящие дедлайны\n"
    help_text += "/today - Дедлайны на сегодня\n"
    help_text += "/week - Дедлайны на неделю\n\n"
    
    # Команды управления уведомлениями
    help_text += "<b>🔹 Управление уведомлениями:</b>\n"
    help_text += "/mute [дни] - Отключить уведомления\n"
    help_text += "/unmute - Включить уведомления\n"
    help_text += "/export - Экспорт данных в JSON\n\n"
    
    # Административные команды
    if is_admin:
        help_text += "<b>🔹 Административные команды:</b>\n"
        help_text += "/status - Статистика системы\n"
        help_text += "/check - Ручной запуск проверки\n"
        help_text += "/search <запрос> - Поиск клиента\n\n"
    
    help_text += "<i>💡 Бот автоматически отправляет уведомления за 14, 7 и 3 дня до истечения срока.</i>"
    
    await message.answer(help_text, parse_mode='HTML')


# Экспортируем роутер для использования в основном приложении
__all__ = ['router']